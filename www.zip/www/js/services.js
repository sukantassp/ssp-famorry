angular.module(FAM_SERVICES)

.factory('BlankFactory', [function(){

}])

.service('BlankService', [function(){

}]);